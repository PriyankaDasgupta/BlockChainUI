function openEditWindow() {
	alert("Edit Employment Details");
	popUpWin = window.open("./Employment.xhtml", "mypopUpWin", "toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbar=no,resizable=no,copyhistory=yes,width=400,height=50");
}